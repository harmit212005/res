
package seleniumtesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Charusat {

    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver","C:\\selenium-java-3.141.59\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();

        try {
            driver.manage().window().maximize();

            // Replace with actual portal URL
            driver.get("https://support.charusat.edu.in/egov/");

            // Enter username
            WebElement username =
                driver.findElement(By.id("25MSIT106"));

            username.sendKeys("25MSIT106");

            // Enter password
            WebElement password =
                driver.findElement(By.id("31Bhaumik40@"));

            password.sendKeys("31Bhaumik40@");

            // Click login
            driver.findElement(By.id("login")).click();

            Thread.sleep(5000);

            System.out.println("Landing Page Title: "
                               + driver.getTitle());

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
        }
    }
}
