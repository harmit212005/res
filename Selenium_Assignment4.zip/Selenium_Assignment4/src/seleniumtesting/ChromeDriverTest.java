
package seleniumtesting;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ChromeDriverTest {

    public static void main(String[] args) {

        // Set ChromeDriver location
        System.setProperty(
            "webdriver.chrome.driver",
            "C:\\selenium-java-3.141.59\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe"
        );

        // Create WebDriver object
        WebDriver driver = new ChromeDriver();

        try {

            // Maximize browser
            driver.manage().window().maximize();

            // Open Google
            driver.get("https://www.google.com");

            // Print browser information
            System.out.println(
                "Page Title: " + driver.getTitle()
            );

            System.out.println(
                "Current URL: " + driver.getCurrentUrl()
            );

            System.out.println(
                "Browser opened successfully!"
            );

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            driver.quit();
        }
    }
}
