
package seleniumtesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.chrome.ChromeDriver;

public class BingSearchTest {

    public static void main(String[] args) {

        // Configure ChromeDriver
       System.setProperty(
            "webdriver.chrome.driver",
            "C:\\selenium-java-3.141.59\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe"
        );

        WebDriver driver = new ChromeDriver();

        try {

            driver.manage().window().maximize();

            // Step 1: Open Bing
            driver.get("https://www.bing.com");

            // Step 2: Find search box
            WebElement searchBox =
                driver.findElement(By.name("q"));

            // Step 3: Enter search keyword
            searchBox.sendKeys(
                "Top 10 software testing tools"
            );

            // Step 4: Press Enter
            searchBox.sendKeys(Keys.ENTER);

            Thread.sleep(3000);

            // Step 5: Print page title
            System.out.println(
                "Page Title: " + driver.getTitle()
            );

        } catch (Exception e) {

            e.printStackTrace();

        } finally {

            driver.quit();
        }
    }
}
